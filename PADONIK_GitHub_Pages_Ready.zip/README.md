# PADONIK

ไฟล์นี้จัดเตรียมสำหรับ GitHub Pages แล้ว

## โครงสร้าง
- index.html = หน้าเว็บไซต์หลัก
- img/ = รูปภาพและไฟล์ประกอบเว็บไซต์

## วิธีเผยแพร่
1. สร้าง GitHub Repository ใหม่
2. อัปโหลดไฟล์และโฟลเดอร์ทั้งหมดใน ZIP นี้เข้า Repository
3. ไปที่ Settings > Pages
4. Source: Deploy from a branch
5. Branch: main / root
6. กด Save
